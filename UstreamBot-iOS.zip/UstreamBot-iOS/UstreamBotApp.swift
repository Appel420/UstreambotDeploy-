
import SwiftUI



@main

struct UstreamBotApp: App {

    var body: some Scene {

        WindowGroup {

            ContentView()

        }

    }

}

