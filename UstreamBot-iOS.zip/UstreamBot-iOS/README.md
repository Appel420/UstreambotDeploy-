
# UstreamBot-iOS



## How to run locally

1. Open **UstreamBotApp.swift** in Xcode (File → Open).

2. Select a simulator or device and press ▶️.

3. Replace YOUR_BACKEND_URL in APIClient.swift with your Flask endpoint.

4. Chat and video PiP will work out of the box.



## Folder contents

- UstreamBotApp.swift — entry point

- ContentView.swift — your UI (video + chat)

- APIClient.swift — real network calls

- Info.plist — permissions & PiP

